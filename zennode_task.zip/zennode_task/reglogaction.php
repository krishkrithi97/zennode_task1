<?php
  include("connection.php");
  session_start();
  if(isset($_POST['submit']))
  {
    $name=$_POST['Name'];
//echo $name;
    $email=$_POST['Email'];
//echo $email;
    $pass=$_POST['CreatePassword'];
    $salt = "task1";
    $password_encrypted = sha1($pass.$salt);
//echo $pass;

    $sql="Insert into user(name,email,password,status,role) values('$name','$email','$password_encrypted',0,'user')";
    $obj=new db();
    $obj->execute($sql);
    $select="select login_id,role from user where email='$email' and password='$password_encrypted'";
    $login=$obj->execute($select);
    if(mysqli_num_rows($login)>0)
   {
       while($row=mysqli_fetch_array($login))
         {
              if($row['role']=='user' && $row['status'==0])
                 {
                       $_SESSION['lid']=$row['login_id'];
                       $_SESSION['role']=$row['role'];
                       header("location:userhome.php");
                 }

          }

		           }

		       }


  //header("location:userhome.php");
?>
