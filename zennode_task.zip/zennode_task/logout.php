<?php
session_start();
if(isset($_SESSION['lid'])&& $_SESSION['lid']!="")
{
  $_SESSION['lid']="";
  unset($_SESSION['lid']);
  session_destroy();
  header("location: login.php");
  
}
else
{
   header("location: login.php");
}

?>