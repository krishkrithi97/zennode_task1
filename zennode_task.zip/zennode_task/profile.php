<?php
  include("connection.php");
  include("check_session.php");

  $sel="select name from user where login_id=$lid";
  $obj=new db();
  $login=$obj->execute($sel);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8">
      <title>Proile</title>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="css/homestyle.css">
  </head>
  <body>
      <header>
        <div class="wrapper">
          <ul class="nav-area">
            <li><a href="userhome.php">Home</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
        <div class="welcome-text">
          <h2 style="color: red;">View Profile & Edit</h2>
          <br><br>
          <?php
              $Lid=$_SESSION['lid'];
              if($Lid>0)
              {
	               $obj=new db();
	               $select="select * from user where login_id='$Lid'";
	               $data=$obj->execute($select);
	               $row=mysqli_fetch_array($data);
	         ?>

           <form action="editaction.php" name="staff" method="post" id="staff">
             <label for="name" style="color:white">Name</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
             <input name="name" value="<?php echo $row['name'];?>" class="input-lg" type="text"  id="name" style="font-size:18px; width:400px" placeholder="Full Name" autofocus required>
             <br>
             <br>
             <label for="email" style="color:white">Email</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
             <input name="email" value="<?php echo $row['email'];?>" class="input-lg" type="text"  id="email" style="font-size:18px; width:400px" placeholder="Email" autofocus required>
             <br>
             <br>
             <center><input type="submit" class="button" value="Edit Profile" name="submit" id="submit" style="font-size:18px"></center><br>
             <a href="delete.php?id= <?php echo $row['login_id']; ?>" onclick="return confirm_alert(this);">Delete Account
          </form>
          <?php
                }
          ?>
        </div>
      </header>
    </body>
</html>
