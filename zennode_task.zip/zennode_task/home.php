<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Home</title>
  	<link rel="stylesheet" type="text/css" href="css/style.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script language="javascript" src="js/sketch.js"></script>
    <script language="javascript" src="js/jquery.js"></script>
    <script language="javascript" src="https://cdn.jsdelivr.net/npm/p5@1.2.0/lib/p5.min.js"></script>

  </head>
  <body class="bodyhome">
	<!-- Main content starts here.. -->
    		<div class="moved">
    			<h1 class="mainheading"><b>Hello User!</b></h1><br><br>
          	<!-- javascript timer id is passed inside the span tag.. -->
    			<p class="logoutmainpara">Our service will be ready in <span class="spanlogout" id="timer">00:10</span></<p><br>
    		 <p class="logout"><strong><a href="#" class="underline" >Logout</a></strong></p>
    		</div>

	<!-- Main content ends here.. -->
  </body>
</html>
