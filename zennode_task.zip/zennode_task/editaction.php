<?php
  include('connection.php');
  include("check_session.php");

  $id=$_SESSION['lid'];
  //echo $id;
  if($id>0)
  {
    $name=$_POST['name'];
    //echo $name;
    $email=$_POST['email'];
    //echo $email;

    $sql="update user set name='$name',email='$email' where login_id='$id'";
    $obj=new db();
    $obj->execute($sql);
  }
  header("location:profile.php");
?>
