<?php
  include("check_session.php");
  $id=$_GET['id'];
  //echo $id;
  include("connection.php");
  $upd="delete from user WHERE login_id=$id";
  $obj=new db();
  $obj->execute($upd);
  if($obj)
  {
 ?>
  <script>
    alert("Account deleted Sucessfully");
    window.location="login.php";
  </script>
<?php
  }
  else
  {
  ?>
    <script>
      alert("Account not deleted Sucessfully");
      window.location="login.php";
    </script>
  <?php
  }
 // header("location:addpackage.php");
  ?>
