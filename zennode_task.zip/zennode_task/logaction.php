<?php
  include("connection.php");
  session_start();
  if(isset($_POST['submit']))
  {
	  $email=$_POST['Email'];
	    //echo $email;
	  $pass=$_POST['Password'];
	    //echo $pass;
    $salt = "task1";
    $password_encrypted = sha1($pass.$salt);

	  $obj=new db();
	  $select="select login_id,role from user where email='$email' and password='$password_encrypted'";
	   //echo $select;
	  $data=$obj->execute($select);
	  if(mysqli_num_rows($data)>0)
	  {
		    while($row=mysqli_fetch_array($data))
		      {

			         // if($row['role']=='admin' && $row['status'==1])
			         //    {
  				     //          $_SESSION['lid']=$row['login_id'];
				       //          $_SESSION['role']=$row['role'];
				       //          header("location:../Admin/adminhome.php");
			         //     }
			         if($row['role']=='user' && $row['status'==0])
			            {
				                $_SESSION['lid']=$row['login_id'];
				                $_SESSION['role']=$row['role'];
				                header("location:userhome.php");
			            }

		       }
    }
	  else
	   {
		     ?>
		       <script>
		         alert("check username and password");
		         window.location="login.php";
		       </script>
		     <?php
		//echo "err";

	 }
  }
?>
