$(function () {
  // Hide all elements which id starts with text.
  $("[id^=text]").hide();

  $(".register-link").click(function (event) {
      event.preventDefault();
      $('#form-login').addClass('hide-el');
      $('#form-reg').removeClass('hide-el');
  });

  $(".login-link").click(function (event) {
      event.preventDefault();
      $('#form-reg').addClass('hide-el');
      $('#form-login').removeClass('hide-el');
  });
});
