$(function() {

	$("#name_error_message").hide();
	//$("#lname_error_message").hide();
	$("#password_error_message").hide();
	$("#email_error_message").hide();


	var error_name = false;
	/*var error_lname = false;*/
	var error_password = false;
	var error_email = false;
	//var error_address = false;
	var pattern = /^[a-zA-Z]*$/;

//first name
	$("#Name").focusout(function() {
		check_username();
		//alert("error");
	});
	//email
	$("#Email").focusout(function() {
		check_email();
	});
	//pass
	$("#CreatePassword").focusout(function() {
		check_password();
		//alert("err");
	});

	//firstname
	function check_username() {
		var name = $("#Name").val();
		if(pattern.test(name) && name != '')
		{

			$("#name_error_message").hide();
			//$("#name_error_message").html("Should be between 5-20 characters");
			//$("#name").css("border-bottum","2px solid #34f458");

		}
		else
		{
			$("#name_error_message").html("Enter valid name");
			$("#name_error_message").show();
			error_name = true;
			//$( "#FirstName" ).focus();
		}
	}
//email function
	function check_email() {

		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);

		if(pattern.test($("#Email").val()))
		{
			//$("#email_error_message").hide();

		 $('#Email').on('blur', function(){
 		 var email = $('#Email').val();
 		 if (email == '') {
 	   error_email = true;
 		 return;
  	}
 		$.ajax({
      url: 'checkemail.php',
      type: 'post',
      data: {
      	'email_check' : 1,
      	'Email' : email,
      },
      success: function(response){
      	if (response == 'taken' ) {
          error_email = true;
          $("#email_error_message").html("Email already exists");
			$("#email_error_message").show();
          //$('#Email').parent().removeClass();
          //$('#Email').parent().addClass("form_error");
          //$('#Email').siblings("span").text('Sorry... Email already taken');
      	}
      	else if (response == 'not_taken') {
      	  error_email = false;
      	  $("#email_error_message").hide();
      	}
      }
 		});
 	});
	} else {
			$("#email_error_message").html("Enter valid email ");
			$("#email_error_message").show();
			error_email = true;
			//$( "#Email" ).focus();
		}
	}
		function check_password() {

		var password_length = $("#CreatePassword").val().length;

		if(password_length < 6) {
			$("#password_error_message").html("At least 6 characters");
			$("#password_error_message").show();
			error_password = true;
			//$( "#CreatePassword" ).focus();
		} else {
			$("#password_error_message").hide();
		}

	}

	$("#create_customer").submit(function() {
		error_name = false;
		/*error_lname = false;*/
		error_email = false;
		error_password =  false;

		check_username();
		/*check_lname();*/
		check_email();
		check_password();

		if (error_name === false && error_password === false && error_email === false) {
			alert("Registration successful");
			return true;

		}
		else
		{
			alert("Please fill the form correctly");
			return false;
		}
		});
	});
