
$(function() {

	$("#password_error_message").hide();
	$("#email_error_message").hide();

	var error_password = false;
	var error_email = false;
	var pattern = /^[a-zA-Z]*$/;

	//email
	$("#Email").focusout(function() {

		check_email();

	});
	//pass
	$("#Password").focusout(function() {

		check_password();
		//alert("err");
	});

	function check_email() {

		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);

		if(pattern.test($("#Email").val()))
		{
			//$("#email_error_message").hide();

		 $('#Email').on('blur', function(){
 		 		var email = $('#Email').val();
 		 		if (email == '') {
 				error_email = true;
 				return;
 			}

			} else {
			$("#email_error_message").html("Enter valid email ");
			$("#email_error_message").show();
			error_email = true;
			//$( "#Email" ).focus();
			}
		}
		function check_password() {

		var password_length = $("#Password").val().length;

		if(password_length < 6) {
			$("#password_error_message").html("At least 6 characters");
			$("#password_error_message").show();
			error_password = true;
			//$( "#CreatePassword" ).focus();
		} else {
			$("#password_error_message").hide();
		}

	}


	$("#create_cust").submit(function() {

		error_email = false;
		error_password =  false;

		check_email();
		check_password();

		if (error_password === false && error_email === false) {
			alert("Registration successful");
			return true;
		}
		else
		{
			alert("Please fill the form correctly");
			return false;
		}
	});
});
