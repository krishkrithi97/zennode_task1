<?php
  include("connection.php");
  include("check_session.php");

$sel="select name from user where login_id=$lid";
$obj=new db();
$login=$obj->execute($sel);

  //echo $lid;
?>
<!DOCTYPE html>
<!--Code by Divinector (www.divinectorweb.com)-->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/homestyle.css">
</head>
<body>
    <header>
    <div class="wrapper">

<ul class="nav-area">
<li><a href="userhome.php">Home</a></li>
<li><a href="profile.php">Profile</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
<div class="welcome-text">
        <h1>
          <?php
if(mysqli_num_rows($login)>0)
              {

              while($row=mysqli_fetch_array($login))
              {
                ?>

             <marquee width="100%" direction="left" height="100px">   <h2 class="b-w3ltxt  " style="color:blue">Welcome&nbsp<?php echo $row['name'];?></h2></marquee>

                <!--<a href="#about" class="btn btn-banner my-sm-3 mr-2">Read More</a>-->
              <?php
              }
              }
              ?>
    </div>
</header>

</body>
</html>
