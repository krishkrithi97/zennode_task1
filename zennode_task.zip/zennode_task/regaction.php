<?php
  include("connection.php");
  if(isset($_POST['submit']))
  {
    $name=$_POST['Name'];
//echo $name;
    $email=$_POST['Email'];
//echo $email;
    $pass=$_POST['CreatePassword'];
    $salt = "task1";
    $password_encrypted = sha1($pass.$salt);
//echo $pass;

    $sql="Insert into user(name,email,password,status,role) values('$name','$email','$password_encrypted',0,'user')";
    $obj=new db();
    $obj->execute($sql);
    $sel="select login_id from user where email='$email' and password='$password_encrypted'";
    $login=$obj->execute($sel);
  }
  header("location:login.php");
?>
