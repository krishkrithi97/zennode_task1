<!DOCTYPE html>
<html>
	<head>
		<title>
			Login & Register
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script src="js/js/validate.js"> </script>
		<script src="js/main.js"> </script>

  	<script type="text/javascript" language="javascript" src="js/javascripts/jquery.js"> </script>
		<script type="text/javascript" language="javascript" src="js/javascripts/logjs.js"> </script>
		<script type="text/javascript" language="javascript" src="js/javascripts/script.js"> </script>

 	</head>

	<body class="bodyloginregister">
<!-- Main content starts here.. -->
			<div class="container" id="container">
				<div class="form-container sign-up-container">
				</div>
			<div class="form-container sign-in-container">
<!-- Form for Register page.. -->
				<div id="form-reg" class="hide-el">
				   <form  action="regaction.php" id="create_customer" name="create_customer" method="POST"  class="form">
						 <br>
					   <h1 class="header1">Register</h1>
				<!-- social media icons..-->
					   <div  class="social-container">
						     <a  href="#" class="fa fa-facebook"></a>
						     <a href="#" class="fa fa-twitter"><i ></i></a>
					   </div>
					   <span>or use your account</span>
					   <input type="text" name="Name" id="Name" class="input" placeholder="Username">
					  		<span id="name_error_message" style="color:red"></span>
					   <input type="email" name="Email" id="Email" class="input" placeholder="Email">
					   		<span id="email_error_message" style="color:red"></span>
					 	 <input type="password" name="CreatePassword" id="CreatePassword" class="input" placeholder="Password">
					  		<span id="password_error_message" style="color:red"></span>

					   <p><strong>Already have an account?<a class="underline login-link" >Login</a></strong></p>
					   <input type="submit" class="button" value="submit" name="submit" id="submit">

				   </form>
				 </div>
<!-- Form for Login page.. -->
				<div id="form-login" class="">
					<form method="POST"  name="create_cust" id="create_cust" action="logaction.php" class="form">
						<br>
						<h1 class="header1">Login</h1><br>
<!-- social media icons.. -->
						<div class="social-container">
							<a href="#" class="fa fa-facebook"></a>
							<a href="#" class="fa fa-twitter"></a>
						</div><br>
						<span>or use your account</span>


						<input type="email" name="Email" class="input" id="Email" placeholder="Email">
							<span id="email_error_message" style="color:red"></span>

						<input type="password" name="Password" class="input" id="Password" placeholder="Password">
            	<span id="password_error_message" style="color:red"></span>

						<p><strong>New User?<a class="underline register-link">Register</a></strong></p>
						<button type="submit" id="submit" name="submit" class="button">Log In</button>
					</form>
				</div>
			</div> <!-- Main content ends here.. -->
<!-- Here comes the split screen which shows no contents.. -->
				<div class="overlay-container">
					<div class="overlay">
						<div class="overlay-panel overlay-left">
						</div>
					</div>
				</div>
<!-- split screen code ends here.. -->
			</div>
	</body>
</html>
