
  function add_your_fields_meta_box() {
    	add_meta_box(
    		'poem-id', // $id
    		'Cutom Book Review', // $title
    		'show_your_fields_meta_box', // $callback
    		'custom_post_type', // $screen
    		'normal', // $context
    		'high' // $priority
    	);
    }
    add_action( 'add_meta_boxes_book', 'add_your_fields_meta_box' );
